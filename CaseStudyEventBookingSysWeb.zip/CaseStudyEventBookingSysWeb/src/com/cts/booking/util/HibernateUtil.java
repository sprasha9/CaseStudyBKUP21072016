package com.cts.booking.util;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {

	
	public static SessionFactory GetFactory()
	{	
		return new Configuration().configure("com/cts/booking/util/hibernate.cfg.xml").buildSessionFactory();
	}
	
}
