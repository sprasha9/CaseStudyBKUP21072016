package com.cts.booking.entity;

import java.util.Date;

public class Event {
	//add mappings or annotations for the Customer entity class. 
	//Create Many-to Many association relationship between Customer and Event entity and 
	// hence add the collection properties accordingly
	private int eventId;
	private String eventName;

	private Date eventDate;

	private int ticketsAvailable;

	private int locationId;
	
}
