package com.cts.booking.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.cts.booking.entity.Location;
import com.cts.booking.util.HibernateUtil;



public class BookingDao {

	private static SessionFactory factory;
	private static Session session;
	
	
	public static List<Location> getAll() {
		
		session=factory.openSession();
		return session.createQuery("from Location").list();
		
	}

	public static void insertCustomerData() {
		//1. Save Customer Information based on the classification of customer into Existing or New
	}
	
	

	public static void insertEventData() {
		//3. Create a One to Many unidirectional relationship with Location and Event
		//Save Event Info along with Location Info
	}

	public static boolean insertLocationData(Location location) {
		//2. Save Location Info
		boolean status=false;
		
		factory=HibernateUtil.GetFactory();
		session=factory.openSession();
		Transaction trans=session.beginTransaction();
		try {
			session.save(location);
			session.getTransaction().commit();
			status=true;
		} catch (HibernateException e) {
			// TODO: handle exception
			session.getTransaction().rollback();
			status=false;
		}
		return status;
		
	}

	static public void bookAticketForAnEventForAnExsistingCustomer(
			int eventId, int custId, int noOfTicketsRequired) {
			//4. Book tickets for an event for an existing customer
			//Assume the cost of each ticket is Rs. 20.00
	}

	static public void bookAticketForAnEventForNewCustomer(int eventId,
			int custId, int noOfTicketsRequired) {
		//4. Book tickets for an event for an new customer
		//Assume the cost of each ticket is Rs. 20.00

	}

	
	static void getTicketCountListByCustomerForALocationDuringSpecificMonth(
			int custId, int month) {
		//5. List the total number of tickets booked by an Existing Customer for a specific month in a location
	}
	
	public static void getAmountsForAnEvent(int eventId){
		//6. List the total sales amount for a particular event
	}
	

}
