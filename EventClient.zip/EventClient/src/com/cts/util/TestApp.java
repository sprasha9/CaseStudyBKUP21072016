package com.cts.util;

import java.io.StringReader;

import javax.json.Json;
import javax.ws.rs.core.*;


import com.sun.jersey.api.client.*;
import com.sun.jersey.api.client.config.*;

public class TestApp {
	public static void main(String[] args) {
		ClientConfig clientConfig = new DefaultClientConfig();
		Client client=Client.create(clientConfig);
		WebResource service = client.resource(UriBuilder.fromUri("http://localhost:7072/ImageDemo").build());
		ClientResponse cresponse = 
				service.path("rest").path("/ImageService/getData/28;eventName=training")
				.type("text/plain").get(ClientResponse.class);
		System.out.println(cresponse.getCookies());
		System.out.println(cresponse);
	
	
}
}
