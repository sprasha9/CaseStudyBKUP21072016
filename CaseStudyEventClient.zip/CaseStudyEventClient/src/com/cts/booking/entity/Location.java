package com.cts.booking.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
@Entity
@Table(name="LOCATION_MASTER")
@XmlRootElement
public class Location {
// add the getters and setters for Location entity
// create an association between Location and Event such that they have One to Many unidirectional relationship
// add the collection properties accordingly
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
@Column(name="LOCATION_ID")
	private int locationId;
@Column(name="LOCATION_NAME")
	private String locationName;


public int getLocationId() {
	return locationId;
}
public void setLocationId(int locationId) {
	this.locationId = locationId;
}
public String getLocationName() {
	return locationName;
}
public void setLocationName(String locationName) {
	this.locationName = locationName;
}
	
	

}
